//
//  main.h
//  alice
//
//  Created by Jordan Worona on 2015-06-03.
//  Copyright (c) 2015 apollo. All rights reserved.
//

#ifndef alice_main_h
#define alice_main_h

#include <cstdlib>
#include <iostream>
#include <vector>
#include <ctime>
#include <cmath>

#include "brain.h"




#define e = 2.71;



#endif
