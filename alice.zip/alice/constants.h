//
//  constants.h
//  alice
//
//  Created by Jordan Worona on 2015-06-03.
//  Copyright (c) 2015 apollo. All rights reserved.
//

#ifndef __alice__constants__
#define __alice__constants__

#include <stdio.h>

extern const int   numberofDendritesPerNeuron;
extern const float defaultWeight;
extern const float inputWeight;

#endif /* defined(__alice__constants__) */
