//
//  constants.cpp
//  alice
//
//  Created by Jordan Worona on 2015-06-03.
//  Copyright (c) 2015 apollo. All rights reserved.
//

#include "constants.h"

const int   numberofDendritesPerNeuron  = 26;
const float defaultWeight               = 0.51;
const float inputWeight                 = 0.6;